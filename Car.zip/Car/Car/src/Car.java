
package com.mycompany.car;

import java.util.ArrayList;
import javax.swing.*;
import java.awt.Dimension;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class Car extends JLabel implements Runnable {
   
    ImageIcon car ;
    int id ;
    int x;
    int y;
    static boolean[]  state ; 
    static int[] postionExitCar ;  
     public Car()
    {
        this.id=1;
        this.x=-200 ;
        this.y=160 ;
        car=new ImageIcon("src/img/car"+this.id+".png");
        this.setIcon(car);
        Dimension size = this.getPreferredSize();
        setBounds(x, y, size.width, size.height);
        state=new boolean[4]; 
        postionExitCar=new int[4];
        for(int i=0 ; i<state.length;i++)
         {
               state[i]=false ; 
         }
        for(int i=0 ; i<postionExitCar.length;i++)
         {
               postionExitCar[i]=-300 ; 
         }
    }
       public Car(int id)
    {
        this.id=id;
        this.x=-200 ;
        this.y=160 ;
        car=new ImageIcon("src/img/car"+this.id+".png");
        Icon cRar;
        this.setIcon(cRar);
        Dimension size = this.getPreferredSize();
        setBounds(x, y, size.width, size.height);
        state=new boolean[4];
        postionExitCar=new int[4];
        for(int i=0 ; i<state.length;i++)
         {
               state[i]=false ; 
         }
        for(int i=0 ; i<postionExitCar.length;i++)
         {
               postionExitCar[i]=-300 ; 
         }
    }
     
 
   public void setIconParking(int i)
   {
       car=new ImageIcon("src/img/car"+i+"_"+i+".png");
       this.setIcon(car);
   }
    public void setIconExitParking(int id)
   {
        car=new ImageIcon("src/img/car"+this.id+".png");
        this.setIcon(car);
   }
    
    
     public void  entrePark()
    {
        
        System.out.println("car "+this.id+" is Parking");
        int[] c=new int[4] ;
        
        for(int i =0 ; i<c.length;i++) // initializes to empty
        {
            c[i]=0;
        }
        
        for(int i=0 ; i<4 ; i++) // check if blocks is empty
        {
            if(!Parking.blocEtat[i])
            {
               c[i]=1;
            }
   
        }
            
        int b=0 ; 
         for(int i=0 ; i<4 ; i++) 
        {
            if(c[i]==1)
            {
               b++;
            }
   
        }

        if(b==0) {    
            for(int i=0 ; i<state.length;i++)
         {
            if(state[i])// check if state 1 indicating an occupied parking spot. 
                {
                    try { 
                    Thread.sleep(100);  
                } catch (InterruptedException ex) {
             Logger.getLogger(Car.class.getName()).log(Level.SEVERE, null, ex);
                }// If an error occurs, log it in the log
              
               }
         }
            
            System.out.println("Empty blocks : "+b);
            Animation.moveIN(this,1080, this.y, 290);
        } 
      
        if(b==1){ 
                      if(c[0]==1){
                System.out.println("Empty block : 1 ");
                System.out.println("Target block : 1 ");
                Animation.moveIN(this,  290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true;
            }
            else if(c[1]==1)
            {               
                 System.out.println("Empty block : 2 ");
                 System.out.println("Target block : 2 ");
                 Animation.moveIN(this, 430, this.y, 290);
                 Animation.parking(this, this.x, this.y);
                 Parking.blocEtat[1]=true;
            }
            else if(c[2]==1) 
            {
                System.out.println("Empty block : 3 ");
                 System.out.println("Target block : 3 ");
                 Animation.moveIN(this,560, this.y, 290);
                 Animation.parking(this, this.x, this.y);
                 Parking.blocEtat[2]=true;
            }
            else if(c[3]==1) 
            {
                System.out.println("Empty block : 4 ");
                 System.out.println("Target block : 4 ");
                 Animation.moveIN(this,700, this.y, 290);
                 Animation.parking(this, this.x, this.y);
                 Parking.blocEtat[3]=true;
            }           
        }
        
       
        if(b==2){         
            int x= (int)(Math.random() * 2) + 1 ;
    
            if(c[0]==1 && c[1]==1){ //1 and 2  
               System.out.println("Empty blocks : 1 , 2 "); 
                if(x==1)
                {
                System.out.println("Target block : 1 ");
                Animation.moveIN(this, 290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true; 
                }
                else {
                System.out.println("Target block : 2 ");
                Animation.moveIN(this, 430, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[1]=true;
                }
            }
            else if(c[0]==1 && c[2]==1) //1 and 3
            {
                System.out.println("Empty blocks : 1 , 3 ");
                 if(x==1)
                {
                System.out.println("Target block: 1 ");
                Animation.moveIN(this,290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true; 
                }
                else {
                System.out.println("Target block : 3 ");
                Animation.moveIN(this,560, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[2]=true;
                }
            }
           
            else if(c[0]==1 && c[3]==1) // 1 and 4
            {
                System.out.println("Empty blocks : 1 , 4 ");
                 if(x==1)
                {
                System.out.println("Target block : 1 ");
                Animation.moveIN(this, 290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true; 
                }
                else {
                System.out.println("Target block : 4 ");
                Animation.moveIN(this, 700, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[3]=true;
                }
            }
             else if(c[1]==1 && c[2]==1) // 2 and 3
            {
                System.out.println("Empty blocks : 2 , 3 ");
                 if(x==1)
                {
                System.out.println("Target block : 2 ");
                Animation.moveIN(this, 430, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[1]=true; 
                }
                else {
                System.out.println("Target block : 3 ");
                Animation.moveIN(this, 560, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[2]=true;
                }
            }
             else if(c[1]==1 && c[3]==1) // 2 and 4
            {
                System.out.println("Empty blocks : 2 , 4 ");
                 if(x==1)
                {
                System.out.println("Target block : 2 ");
                Animation.moveIN(this,430, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[1]=true; 
                }
                else {
                System.out.println("Target block : 4 ");
                Animation.moveIN(this,700, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[3]=true;
                }
            }
             else if(c[2]==1 && c[3]==1) // 3 and 4
            {
                System.out.println("Empty blocks : 3 , 4 ");
                 if(x==1)
                {
                System.out.println("Target block : 3 ");
                Animation.moveIN(this,560, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[2]=true; 
                }
                else {
                System.out.println("Target block : 4 ");
                Animation.moveIN(this, 700, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[3]=true;
                }
            }
            
        }
        
        
        if(b==3)
        {
            
            int x= (int)(Math.random() * 3) + 1 ;
            System.out.println("x: "+x);
            
            if(c[0]==1 && c[1]==1 && c[2]==1) // 1 2 3
            {  
            System.out.println("Empty blocks : 1 , 2 , 3 ");
            if(x==1)
            {
                System.out.println("Target block : 1 ");
                Animation.moveIN(this,290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true;
            }
            else if(x==2)
            {
                 System.out.println("Target block : 2 ");
                Animation.moveIN(this, 430, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[1]=true;
            }
            else if(x==3)
            {
                 System.out.println("Target block : 3 ");
                Animation.moveIN(this, 560, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[2]=true;
            }
            }
            
             if(c[0]==1 && c[1]==1 && c[3]==1) //1 2 4
            {
                
            System.out.println("Empty blocks : 1 , 2 , 4 ");
            if(x==1)
            {
                System.out.println("Target block : 1 ");
                Animation.moveIN(this, 290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true;
            }
            else if(x==2)
            {
                 System.out.println("Target block : 2 ");
                Animation.moveIN(this, 430, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[1]=true;
            }
            else if(x==3)
            {
                 System.out.println("Target block : 4 ");
                Animation.moveIN(this,700, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[3]=true;
            }
            }
              if(c[0]==1 && c[2]==1 && c[3]==1) //1 3 4
            {
                
            System.out.println("Empty blocks : 1 , 3 , 4 ");
            if(x==1)
            {
                System.out.println("Target block : 1 ");
                Animation.moveIN(this, 290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true;
            }
            else if(x==2)
            {
                 System.out.println("Target block : 3 ");
                Animation.moveIN(this, 560, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[2]=true;
            }
            else if(x==3)
            {
                 System.out.println("Target block : 4 ");
                Animation.moveIN(this, 700, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[3]=true;
            }
            }
             if(c[1]==1 && c[2]==1 && c[3]==1) //2 3 4
            {
                
            System.out.println("Empty blocks : 2 , 3 , 4 ");
            if(x==1)
            {
                System.out.println("Target block : 2 ");
                Animation.moveIN(this,430, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[1]=true;
            }
            else if(x==2)
            {
                 System.out.println("Target block : 3 ");
                Animation.moveIN(this,560, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[2]=true;
            }
            else if(x==3)
            {
                System.out.println("Target block : 4 ");
                Animation.moveIN(this,700, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[3]=true;
            }
            }    
            
        }
        
        
        if(b==4)
        {
            int x= (int)(Math.random() * 4) + 1 ;
            System.out.println("x: "+x);
            
            System.out.println("Empty blocks : 1 , 2 , 3 , 4 ");
            if(x==1)
            {
                
                System.out.println("Target block : 1 ");
                Animation.moveIN(this, 290, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[0]=true;
            }
            else if(x==2)
            {
                 System.out.println("Target block : 2 ");
                Animation.moveIN(this, 430, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[1]=true;
            }
            else if(x==3)
            {
                System.out.println("Target block : 3 ");
                Animation.moveIN(this,  560, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[2]=true;
            }
            else if(x==4)
            {
                System.out.println("Target block : 4 ");
                Animation.moveIN(this, 700, this.y, 290);
                Animation.parking(this, this.x, this.y);
                Parking.blocEtat[3]=true;
            }
            
        }
   
        
     
        Animation.moveIN(this, this.x, this.y, 290);
        
        if(Parking.blocEtat[0]==false)
        {
              Animation.parking(this, this.x, this.y);
              Parking.blocEtat[0]=true;
        }
        else 
        {
           Animation.moveIN(this, this.x, this.y, 430);
             if(Parking.blocEtat[1]==false)
        {
              Animation.parking(this, this.x, this.y);
               Parking.blocEtat[1]=true;
        }
             else {
              Animation.moveIN(this, this.x, this.y,560);
             if(Parking.blocEtat[2]==false)
        {
              Animation.parking(this, this.x, this.y);
               Parking.blocEtat[2]=true;
             }
             
             else {
                  
             Animation.moveIN(this, this.x, this.y, 1000);
                 
             }
            
        }      
    }
        
        
    }
     public void sortiPark()
    {
        System.out.println("car "+this.id+" is going out");
        
          
           if(this.x<=300) // block 1
           {   
              state[0]=true ;
              postionExitCar[0]=this.x;
              Animation.exitParking(this);
              state[0]=false ;
              postionExitCar[0]=-300;
              Parking.blocEtat[0]=false;
              Animation.moveOut(this);
             
           }
            if(this.x>=290 && this.x<=450) //block 2
           {  
              state[1]=true ;
              postionExitCar[1]=this.x;
              Animation.exitParking(this);
              state[1]=false ;
              postionExitCar[1]=-300;
              Parking.blocEtat[1]=false;
              Animation.moveOut(this);    
              
           }
            if(x>=450 && x<=700) // block 3
           {
              state[2]=true ;
              postionExitCar[2]=this.x;
              Animation.exitParking(this);
              state[2]=false ;
              postionExitCar[2]=-300;
              Parking.blocEtat[2]=false;
              Animation.moveOut(this);    
             
           }
             if(x>=700 && x<=1080) // bloc 4
           {  
              state[3]=true ;
              postionExitCar[3]=this.x;
              Animation.exitParking(this);
              state[3]=false ;
              postionExitCar[3]=-300;
              Parking.blocEtat[3]=false;
              Animation.moveOut(this);    
              
           }
             
           
             
     }

    @Override
     public void run() {
   
        try {
            
            Random random = new Random();
            int x= (int)(Math.random() * 10000) + 6000 ;
            System.out.println("car : "+this.id+" Parking Time(s) : "+x/1000);  
           
            Parking.semaphoreEntree.acquire(); 
            this.entrePark();
            Parking.semaphoreEntree.release();
           
            Thread.sleep(x);
            
            Parking.semaphoreSortie.acquire();
            this.sortiPark();
            Thread.sleep(6000);
            Parking.semaphoreSortie.release();
            
             Thread.sleep(6000);
            
            if(random.nextBoolean()) Thread.sleep(100);
        } catch (InterruptedException ex) {
            Logger.getLogger(Car.class.getName()).log(Level.SEVERE, null, ex);
        }


    }





    
    public static void main(String[] args) {
    
        
        JFrame frame = new JFrame("Parking Simulator");
        Parking panel = new Parking();
        frame.setContentPane(panel);
        panel.setLayout(null);
        frame.setSize(1090, 400);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ArrayList<Car> cars=new ArrayList<Car>();
        
        Car c1 = new Car(1);
        Car c2 = new Car(2);
        Car c3 = new Car(3);
        Car c4 = new Car(4);
        Car c5 = new Car(5);
        Car c6 = new Car(6);
        Car c7 = new Car(7);
        Car c8 = new Car();
   
        Thread t1 = new Thread(c1);
        Thread t2 = new Thread(c2);
        Thread t3 = new Thread(c3);
        Thread t4 = new Thread(c4);
        Thread t5 = new Thread(c5);
        Thread t6 = new Thread(c6);
        Thread t7 = new Thread(c7);
        Thread t8 = new Thread(c7);
      
        panel.add(c1);
        panel.add(c2);
        panel.add(c3);
        panel.add(c4);
        panel.add(c5);
        panel.add(c6);
        panel.add(c7);  
        panel.add(c8);
       
      for(int i=1 ; i<=3 ; i++)
      {   
          Car c = new Car(i); 
          cars.add(c);
          panel.add(c);
       } 
      
      for(Car c : cars)
      {
          Thread t=new Thread(c);
          t.start();
      }
      frame.setVisible(true);
       
    
    }

}



